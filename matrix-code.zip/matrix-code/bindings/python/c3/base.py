#!/usr/bin/env python
'''
Author: Caterina Valdovinos
Date: 3/6/2020
Description: Base acts as the setup portion for the 32x32 matrix frame, GPIO mappings, etc.
'''
import argparse
import time
import sys
import os

sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/..'))
from rgbmatrix import RGBMatrix, RGBMatrixOptions

'''
Base : acts as the setup portion for the 32x32 matrix frame, GPIO mappings, etc.
'''
class Base(object):
    def __init__(self):
        '''
        __init__ : outputs "created matrix" (used for debugging)
        '''
        print("created matrix")

    def run(self):
        '''
        run : outputs "Running" (used for debugging)
        '''
        print("Running")

    def process(self):
        '''
        process : configures the system to the hardware and runs the process()
        '''
        # Configure the RGBMatrix to 32x32 Adafruit using Rasberry Pi
        options = RGBMatrixOptions()
        options.gpio_slowdown = 4
        options.disable_hardware_pulsing = True
        options.hardware_mapping = "classic-pi1"   
        self.matrix = RGBMatrix(options = options)

        # Runs until CTRL-C is pressed by user
        try:
            print("Press CTRL-C to stop sample")
            self.run()
        except KeyboardInterrupt:
            print("Exiting\n")
            sys.exit(0)

        return True

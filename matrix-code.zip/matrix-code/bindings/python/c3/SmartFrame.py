#!/usr/bin/env python
'''
Author: Caterina Valdovinos
Date: 3/6/2020
Description: SmartFrame formats a Base display in accordance to wants of the display.
'''
from base import Base
from rgbmatrix import graphics
import time
from PIL import Image
from datetime import datetime
import sys
import quickstart
import requests
import json


'''
SmartFrame formats a Base display in accordance to wants of the display.
'''
class SmartFrame(Base):
    
    def __init__(self):
        '''
        __init__ : initalizes the SmartFrame's attributes
        '''
        super(SmartFrame, self).__init__()
        
        # Gets command line args and sets them accordingly
        self.show_time = True if sys.argv[1] == "1" else False
        self.show_weather = True if sys.argv[2] == "1" else False
        self.show_calander = True if sys.argv[3] == "1" else False
        
        # Initializes the color for each text element
        self.time_color = graphics.Color(255, 255, 255)
        self.weather_color = graphics.Color(0, 20, 255)
        self.annouce_header_color = graphics.Color(255, 0, 0)
        self.annouce_descpt_color = graphics.Color(100, 200, 255)
        
        # Gets the weather if necessary
        self.weather_str = ""
        if self.show_weather:
            self.set_weather()
        
        # Gets the calander events if necessary
        self.annc_q = []
        if self.show_calander:
            self.set_calander_events()
    
    def set_weather(self):
        '''
        set_weather : gets the weather from an api and sets the object's attribute for it
        '''
        apiCall = 'https://api.openweathermap.org/data/2.5/weather?q=Spokane&appid=baf131fb3ed6dea0cd72bf8aeb8762dd';
        
        response = requests.get(apiCall)
        
        # Get weather information from json
        weather_stuff = response.json()['weather']
        
        #goes through the JSON as if it is a dict. and when it finds
        #element 'description' it sets weather_str to what its associated value
        for item in weather_stuff:
            self.weather_str = item['description']

    def set_calander_events(self):
        '''
        set_calander_events : gets the events from the google calander api and sets the object's attribute for it
        '''
        self.annc_q = quickstart.main()
                  
    def run(self):
        '''
        run : Initializes a canvas for the matrix and goes into each version and decides whether or not to stay based
                on the user requests
        '''
        offscreen_canvas = self.matrix.CreateFrameCanvas()
        
        #Decide which display version is appropriete
        self.version_1(offscreen_canvas)
        self.version_2_1(offscreen_canvas)
        self.version_2_2(offscreen_canvas)
        self.version_3(offscreen_canvas)
            
    def version_1(self, offscreen_canvas):
        '''
        version_1 : displays the time and weather as well as events if wanted
                    Display resemmbles:
                    :::HH:MM:::::
                    :::weather:::
                    EVENT::::::::
                    (event title)
        '''
        time_font = graphics.Font()
        weather_font = graphics.Font()
        annouce_header_font = graphics.Font()
        annouce_descpt_font = graphics.Font()
        
        # Adjust the font being used for each displayed text
        time_font.LoadFont("../../../fonts/5x7.bdf")
        weather_font.LoadFont("../../../fonts/5x7.bdf")
        annouce_header_font.LoadFont("../../../fonts/6x9.bdf")
        annouce_descpt_font.LoadFont("../../../fonts/5x7.bdf")
        
        # Initialize variables outside incremental scope
        xpos_weather = xpos_d = annc_q_index = announment_round = 0
        
        while (self.show_time and self.show_weather):
            offscreen_canvas.Clear()
            
            # Is the annuncement queue empty?
            if ((len(self.annc_q) != 0) and (self.show_calander)):
                announment_round += 1
                        
                 # Add the annuncement to the display
                annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,22, self.annouce_header_color, "EVENT")
                annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                        
                xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                        
                # Change the announcement after 3 scrolls
                if ((announment_round/annouce_descpt_len) == 3):
                    annc_q_index += 1
                    announment_round = 0
                    xpos_d = 0
                    
                    #Reset if at the end
                    if (annc_q_index == len(self.annc_q)):
                        annc_q_index = 0
                    
                    # Add the annuncement to the display
                    offscreen_canvas.Clear()
                    annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,22, self.annouce_header_color, "EVENT")
                    annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                    xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
            
            # Get the current time 
            current_time = datetime.now()
            str_time = current_time.strftime("%H:%M")
            
            # If time is HH:_0 update weather & events
            if int(current_time.strftime("%M"))%10 == 0:
                if int(current_time.strftime("%S")) == 00:
                    self.set_weather()
                    self.set_calander_events()
            
            # Add the time and weather to the display
            time_len = graphics.DrawText(offscreen_canvas, time_font, 4,8, self.time_color, str_time)
            weather_len = graphics.DrawText(offscreen_canvas, weather_font, xpos_weather,15, self.weather_color, self.weather_str)
            
            #Adjust the positioning for the scrolling weather text
            xpos_weather -= 1    
            if (xpos_weather + weather_len < 0):
                xpos_weather = offscreen_canvas.width 

            time.sleep(0.1)
            
            # Set the offscreen info to on screen
            offscreen_canvas = self.matrix.SwapOnVSync(offscreen_canvas)
        
    def version_2_1(self, offscreen_canvas):
        '''
        version_2_1 : displays the time as well as events if wanted
                    Display resemmbles:
                    :::H H:M M:::
                    :::::::::::::
                    EVENT::::::::
                    (event title)
                    :::::::::::::
        '''
        time_font = graphics.Font()
        annouce_header_font = graphics.Font()
        annouce_descpt_font = graphics.Font()        
        
        # Adjust the font being used for each displayed text
        time_font.LoadFont("../../../fonts/6x13.bdf")
        annouce_header_font.LoadFont("../../../fonts/6x13.bdf")
        annouce_descpt_font.LoadFont("../../../fonts/6x13.bdf")
        
        # Initialize variables outside incremental scope
        xpos_weather = xpos_d = annc_q_index = announment_round = 0
        
        while (self.show_time and not self.show_weather):
            offscreen_canvas.Clear()
            # Is the annuncement queue empty?
            if ((len(self.annc_q) != 0) and (self.show_calander)):
                announment_round += 1
                        
                 # Add the annuncement to the display
                annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,20, self.annouce_header_color, "EVENT")
                annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                        
                xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                        
                # Change the announcement after 3 scrolls
                if ((announment_round/annouce_descpt_len) == 3):
                    annc_q_index += 1
                    announment_round = 0
                    xpos_d = 0
                    
                    #Reset if at the end
                    if (annc_q_index == len(self.annc_q)):
                        annc_q_index = 0
                    
                    # Add the annuncement to the display
                    offscreen_canvas.Clear()
                    annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,20, self.annouce_header_color, "EVENT")
                    annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                    xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                    
            # Get the current time 
            current_time = datetime.now()
            str_time = current_time.strftime("%H:%M")
            
            # If time is HH:_0 update weather & events
            if int(current_time.strftime("%M"))%10 == 0:
                if int(current_time.strftime("%S")) == 00:
                    self.set_calander_events()
            
            # Add the time and weather to the display
            time_len = graphics.DrawText(offscreen_canvas, time_font, 1,10, self.time_color, str_time)
            time.sleep(0.1)
            
            # Set the offscreen info to on screen
            offscreen_canvas = self.matrix.SwapOnVSync(offscreen_canvas)
    
    def version_2_2(self, offscreen_canvas):
        '''
        version_2_2 : version_2_1 : displays the weather as well as events if wanted
                    Display resemmbles:
                    :::Weather:::
                    :::::::::::::
                    EVENT::::::::
                    (event title)
                    :::::::::::::
        '''
        weather_font = graphics.Font()
        annouce_header_font = graphics.Font()
        annouce_descpt_font = graphics.Font()

        # Adjust the font being used for each displayed text
        weather_font.LoadFont("../../../fonts/7x13B.bdf")
        annouce_header_font.LoadFont("../../../fonts/6x13.bdf")
        annouce_descpt_font.LoadFont("../../../fonts/6x13.bdf")
        
        # Initialize variables outside incremental scope
        xpos_weather = xpos_d = annc_q_index = announment_round = 0
        
        while (not self.show_time and self.show_weather):
            offscreen_canvas.Clear()
            # Is the annuncement queue empty?
            if ((len(self.annc_q) != 0) and (self.show_calander)):
                announment_round += 1
                        
                 # Add the annuncement to the display
                annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,20, self.annouce_header_color, "EVENT")
                annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                        
                xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                        
                # Change the announcement after 3 scrolls
                if ((announment_round/annouce_descpt_len) == 3):
                    annc_q_index += 1
                    announment_round = 0
                    xpos_d = 0
                    
                    #Reset if at the end
                    if (annc_q_index == len(self.annc_q)):
                        annc_q_index = 0
                    
                    # Add the annuncement to the display
                    offscreen_canvas.Clear()
                    annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,20, self.annouce_header_color, "EVENT")
                    annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,30, self.annouce_descpt_color, self.annc_q[annc_q_index])
                    xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                    
            # Add the weather to the display
            weather_len = graphics.DrawText(offscreen_canvas, weather_font, xpos_weather,10, self.weather_color, self.weather_str)
            
            # If time is HH:_0 update weather & events
            if int(current_time.strftime("%M"))%10 == 0:
                if int(current_time.strftime("%S")) == 00:
                    self.set_weather()
                    self.set_calander_events()
            
            #Adjust the positioning for the scrolling weather text
            xpos_weather -= 1    
            if (xpos_weather + weather_len < 0):
                xpos_weather = offscreen_canvas.width 

            time.sleep(0.1)
            
            # Set the offscreen info to on screen
            offscreen_canvas = self.matrix.SwapOnVSync(offscreen_canvas)
    
    def version_3(self, offscreen_canvas):
        '''
        version_3 : version_2_1 : displays the events if wanted
                    Display resemmbles:
                    :::::::::::::
                    :EVENT:::::::
                    :::::::::::::
                    (event title)
                    :::::::::::::
        '''
        annouce_header_font = graphics.Font()
        annouce_descpt_font = graphics.Font()
        
        # Adjust the font being used for each displayed text
        annouce_header_font.LoadFont("../../../fonts/6x13.bdf")
        annouce_descpt_font.LoadFont("../../../fonts/9x15.bdf")
        
        # Initialize variables outside incremental scope
        xpos_weather = xpos_d = annc_q_index = announment_round = 0
        
        while (not self.show_time and  not self.show_weather):
            offscreen_canvas.Clear()
            # Is the annuncement queue empty?
            if ((len(self.annc_q) != 0) and (self.show_calander)):
                announment_round += 1
                        
                 # Add the annuncement to the display
                annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,10, self.annouce_header_color, "EVENT")
                annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,25, self.annouce_descpt_color, self.annc_q[annc_q_index])
                        
                xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)
                        
                # Change the announcement after 3 scrolls
                if ((announment_round/annouce_descpt_len) == 3):
                    annc_q_index += 1
                    announment_round = 0
                    xpos_d = 0
                    
                    #Reset if at the end
                    if (annc_q_index == len(self.annc_q)):
                        annc_q_index = 0
                    
                    # Add the annuncement to the display
                    offscreen_canvas.Clear()
                    annouce_header_len = graphics.DrawText(offscreen_canvas, annouce_header_font, 0,10, self.annouce_header_color, "EVENT")
                    annouce_descpt_len = graphics.DrawText(offscreen_canvas, annouce_descpt_font, xpos_d,25, self.annouce_descpt_color, self.annc_q[annc_q_index])
                    xpos_d = self.get_xpos(annouce_descpt_len, xpos_d, offscreen_canvas)

            time.sleep(0.1)
            
            # If time is HH:_0 update weather & events
            if int(current_time.strftime("%M"))%10 == 0:
                if int(current_time.strftime("%S")) == 00:
                    self.set_calander_events()
            
            # Set the offscreen info to on screen
            offscreen_canvas = self.matrix.SwapOnVSync(offscreen_canvas)
          
    #Return s the appropriete xpos depending on whether or not the text must scorll      
    def get_xpos(self,d_len, d_xpos, canvas):
         '''
         get_xpos : calculates the new xpos if the text is too large and therefore must scroll to be fully displayed 
                     or leave the xpos alone because the text doesn't need to scroll
         '''
         scroll_d = True
         
         # if there's no need to scroll
         if d_len <= canvas.width:
             d_xpos = 0
             scroll_d = False
             
         # If descrpt or header need to scroll adjust xpos    
         if scroll_d:
            d_xpos -= 1
            if (d_xpos + d_len < 0):
                d_xpos = canvas.width
         return d_xpos
    
# Main function
if __name__ == "__main__":
    run_frame = SmartFrame()
    if (not run_frame.process()):
        run_frame.print_help()


